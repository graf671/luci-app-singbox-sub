# Build with GitHub Actions

1. Create an empty GitHub repository.
2. Upload the contents of this ZIP to the repository.
3. Open **Actions**.
4. Select **Build luci-app-singbox-sub**.
5. Press **Run workflow**.
6. When the job finishes, open the workflow run and download the artifact:
   `luci-app-singbox-sub-openwrt-24.10.8-mediatek-filogic`.

The workflow uses the official OpenWrt 24.10.8 SDK for:
- target: mediatek/filogic
- architecture: aarch64_cortex-a53

The SDK archive SHA256 is verified before extraction.
