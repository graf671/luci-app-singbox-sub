'use strict';
'require view';
'require form';
'require uci';
'require rpc';
'require ui';

var exec = rpc.declare({
	object: 'file',
	method: 'exec',
	params: [ 'command', 'params' ],
	expect: { stdout: '' }
});

function run(args) {
	return exec('/usr/bin/singbox-sub', args || []);
}

return view.extend({
	load: function() {
		return Promise.all([
			uci.load('singbox_sub'),
			run([ 'status' ]),
			run([ 'backups' ])
		]);
	},

	render: function(data) {
		var status = {};
		var backups = [];

		try { status = JSON.parse(data[1] || '{}'); } catch (e) {}
		try { backups = JSON.parse(data[2] || '[]'); } catch (e) {}

		var m = new form.Map(
			'singbox_sub',
			_('Sing-box Subscription'),
			_('Subscription management, validation, backups and scheduled updates.')
		);

		var s = m.section(form.TypedSection, 'main');
		s.anonymous = true;
		s.addremove = false;

		s.tab('general', _('Settings'));

		var o = s.taboption('general', form.Flag, 'enabled', _('Enabled'));
		o.default = '1';
		o.rmempty = false;

		o = s.taboption('general', form.Value, 'subscription_url', _('Subscription URL'));
		o.password = true;
		o.rmempty = true;

		o = s.taboption('general', form.Value, 'proxies_file', _('Local proxies file'));
		o.rmempty = false;

		o = s.taboption('general', form.Value, 'parser', _('Parser'));
		o.rmempty = false;

		o = s.taboption('general', form.Value, 'config', _('sing-box config'));
		o.rmempty = false;

		o = s.taboption('general', form.Value, 'sing_box', _('sing-box binary'));
		o.rmempty = false;

		o = s.taboption('general', form.Value, 'min_nodes', _('Minimum nodes'));
		o.datatype = 'uinteger';
		o.default = '1';

		o = s.taboption('general', form.Value, 'backup_count', _('Backup count'));
		o.datatype = 'uinteger';
		o.default = '3';

		o = s.taboption('general', form.Value, 'timeout', _('Download timeout'));
		o.datatype = 'uinteger';
		o.default = '30';

		o = s.taboption('general', form.Flag, 'schedule_enabled', _('Automatic updates'));
		o.default = '0';

		o = s.taboption('general', form.Value, 'schedule_minutes', _('Update interval (minutes)'));
		o.datatype = 'uinteger';
		o.default = '360';
		o.description = _('Use an interval that divides 1440 for exact cron scheduling.');

		var statusView = s.taboption('general', form.DummyValue, '_status', _('Status'));
		statusView.rawhtml = true;
		statusView.cfgvalue = function() {
			var html = '<div class="cbi-value-field">';

			if (status.sing_box_found)
				html += '<span style="color:green"><strong>● OK</strong></span> ';
			else
				html += '<span style="color:red"><strong>● sing-box not found</strong></span> ';

			html += '<br>' + _('Nodes') + ': <strong>' + (status.nodes || 0) + '</strong>';

			if (status.sing_box_version)
				html += '<br><code>' + status.sing_box_version + '</code>';

			if (status.last_log)
				html += '<br><small>' + status.last_log + '</small>';

			html += '</div>';
			return html;
		};

		var update = s.taboption('general', form.Button, '_update', _('Subscription'));
		update.inputtitle = _('Update now');
		update.inputstyle = 'apply';
		update.onclick = function() {
			return run([ 'update' ]).then(function(r) {
				ui.addNotification(null,
					E('pre', { 'style': 'white-space:pre-wrap;max-height:400px;overflow:auto' },
						r.stdout || _('Update finished')),
					r.code ? 'error' : 'info');
				location.reload();
			});
		};

		var check = s.taboption('general', form.Button, '_check', _('Validation'));
		check.inputtitle = _('Run sing-box check');
		check.onclick = function() {
			return run([ 'check' ]).then(function(r) {
				ui.showModal(_('sing-box check'), [
					E('pre', { 'style': 'white-space:pre-wrap;max-height:500px;overflow:auto' },
						r.stdout || r.stderr || _('Check finished')),
					E('div', { 'class': 'right' }, [
						E('button', {
							'class': 'btn cbi-button',
							'click': ui.hideModal
						}, [ _('Close') ])
					])
				]);
			});
		};

		var logs = s.taboption('general', form.Button, '_logs', _('Logs'));
		logs.inputtitle = _('Show log');
		logs.onclick = function() {
			return run([ 'logs' ]).then(function(r) {
				ui.showModal(_('Last update log'), [
					E('pre', { 'style': 'white-space:pre-wrap;max-height:500px;overflow:auto' },
						r.stdout || _('No log available')),
					E('div', { 'class': 'right' }, [
						E('button', {
							'class': 'btn cbi-button',
							'click': ui.hideModal
						}, [ _('Close') ])
					])
				]);
			});
		};

		var rb = s.taboption('general', form.ListValue, '_rollback', _('Rollback'));
		rb.value('', _('Select backup...'));
		backups.forEach(function(file) {
			rb.value(file, file);
		});
		rb.write = function(section_id, value) {
			if (!value)
				return;

			return run([ 'rollback', value ]).then(function(r) {
				ui.addNotification(null,
					E('pre', { 'style': 'white-space:pre-wrap' },
						r.stdout || r.stderr || _('Rollback finished')),
					r.code ? 'error' : 'info');
				setTimeout(function() { location.reload(); }, 1000);
			});
		};

		return m.render();
	}
});
