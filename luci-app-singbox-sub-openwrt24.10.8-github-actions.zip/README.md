# luci-app-singbox-sub 1.1.0

LuCI application for OpenWrt 24.10.x and sing-box subscription management.

Target tested for packaging:
- OpenWrt 24.10.x
- mediatek/filogic
- aarch64_cortex-a53

Features:
- UCI configuration
- subscription URL
- local proxy file
- parser and sing-box paths
- minimum node safety threshold
- backup rotation
- pre-apply `sing-box check`
- rollback on reload failure
- manual update
- manual validation
- update log
- backup selection and rollback
- optional scheduled updates
- temporary data in `/tmp`

Dependencies:
- luci-base
- rpcd-mod-file
- uci
- jq
- python3
- uclient-fetch
- coreutils-base64

The package does not install sing-box. Install/configure sing-box Extended separately.

The parser is expected at `/root/parse-proxies.py` by default and must output a JSON array of sing-box outbound objects.
